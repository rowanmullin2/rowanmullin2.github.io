# Community Support Tracker Project

## Project Description
PiXELL River Financial prides itself on being a good citizen. As part of our commitment to the communities in which we live and work, we are developing a Community Support Tracker. This tool will help us monitor and manage our various community support initiatives, ensuring we're making a meaningful impact.

The Community Support Tracker will have three main components:

- Donation Tracker
- Volunteer Hours Tracker
- Event Signup
- Sponsorships Tracker
- In-Kind contributions Tracker

# Group Members
 - Amandeep
 - David
 - Michael
 - Parneet
 - Rowan
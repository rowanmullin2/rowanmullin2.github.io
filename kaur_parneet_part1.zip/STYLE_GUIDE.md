# font
  comic sans

# colours
  Primary Color: #111142
  Secondary Color: #979799
  Tertiary Color: #C96DE5
